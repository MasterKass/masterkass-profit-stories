Логотип МастерКасс

svg/ - векторные исходники (любой размер)
png/ - прозрачный фон, 16-2048 px
android/ - иконки приложения для кассы (папки res/mipmap-*)
kassa/ - 512 px для карточки в Evotor Market
web/ - favicon.ico, apple-touch-icon, icon-192
